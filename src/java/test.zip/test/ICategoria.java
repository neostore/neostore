/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author belchiorpalma
 */
public interface ICategoria {
    public int getIdCategoria();
    public void setIdCategoria(int idCategoria);
    public void print();
    
}
