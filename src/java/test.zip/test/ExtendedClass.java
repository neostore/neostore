/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author belchiorpalma
 */
public class ExtendedClass extends SuperClass implements ICategoria{
    
    
    public static void main(String args[]){
        ExtendedClass e = new ExtendedClass();
        e.print(); // imprimir o método que está implementado na classe categoria ????????
        
    }

    @Override
    public int getIdCategoria() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setIdCategoria(int idCategoria) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void print() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
